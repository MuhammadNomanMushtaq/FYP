import pandas as pd
import joblib
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import struct
# Modbus sensor configuration
from pymodbus.client import ModbusSerialClient

# Load the trained model
model = joblib.load('rf_model.pkl')
sensor_client = None

app = FastAPI()

class PredictionInput(BaseModel):
    N: float
    P: float
    K: float
    EC: float
    temperature: float
    PH: float

    class Config:
        schema_extra = {
            "example": {
                "Temperature": 25.0,
                "N": 50,
                "P": 30,
                "K": 40,
                "pH": 6.5,
                "EC": 1
                
            }
        }

CROP_LABELS = [
    'Wheat','Rice','Cotton','Maize','Sugarcane','Barley','Chickpea','Lentil','Mustard','Sesame','Sunflower'
]

def read_float(client, address):
    try:
        response = client.read_holding_registers(address=address, count=2, slave=1)
        if response.isError():
            return float('nan')
        raw_value = struct.unpack('>f', struct.pack('>HH', *response.registers))[0]
        return raw_value
    except Exception:
        return float('nan')

def read_scaled_int(client, address, factor=10):
    try:
        response = client.read_holding_registers(address=address, count=1, slave=1)
        if not response.isError():
            return response.registers[0] / factor
        return float('nan')
    except Exception:
        return float('nan')

@app.get("/connect")
def connect_sensor():
    try:
        sensor_client = ModbusSerialClient(
            port='COM3',
            baudrate=4800,
            bytesize=8,
            parity='N',
            stopbits=1,
            timeout=2
        )
        if sensor_client.connect():
            sensor_client.close()
            return JSONResponse(content={"connected": True}, status_code=200)
        else:
            return JSONResponse(content={"connected": False}, status_code=503)
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.get("/get-values")
def get_sensor_values():
    try:
        sensor_client = ModbusSerialClient(
            port='COM3',
            baudrate=4800,
            bytesize=8,
            parity='N',
            stopbits=1,
            timeout=2
        )
        if not sensor_client.connect():
            return JSONResponse(content={"error": "Could not connect to sensor"}, status_code=503)
        try:
            temp = read_scaled_int(sensor_client, 0x00)
            ec = read_float(sensor_client, 0x01)
            ph = read_scaled_int(sensor_client, 0x02)
            n = read_float(sensor_client, 0x03)
            p = read_float(sensor_client, 0x04)
            k = read_float(sensor_client, 0x05)

            # average_NPK = (n + p + k) / 3

            # # Assign fertility_label based on average_NPK
            # if average_NPK <= 30:
            #     fertility_label = 2  # low
            # elif average_NPK <= 60:
            #     fertility_label = 1  # medium
            # else:
            #     fertility_label = 0  # high

            return JSONResponse(
                content={
                    
                    "Temperature": temp,
                    "N": n,
                    "P": p,
                    "K": k,
                    "pH": ph,
                    "EC": ec
                    
                  
                },
                status_code=200
            )
        finally:
            sensor_client.close()
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.get("/")
def root():
    return {"message": "Crop prediction API is running."}

@app.post("/predict")
def predict(input: PredictionInput):
    input_df = pd.DataFrame([input.dict()])
    prediction = model.predict(input_df)
    # Map prediction to crop name(s)
    mapped = [CROP_LABELS[p] for p in prediction]
    return {"prediction": mapped}

# input_data = pd.DataFrame([{
#     'N': 50,
#     'P': 30,
#     'K': 40,
#     'average_NPK': (50+30+40)/3,
#     'fertility_label': 1,  # example label
#     'temperature': 25.0,
#     'PH': 6.5
# }])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

